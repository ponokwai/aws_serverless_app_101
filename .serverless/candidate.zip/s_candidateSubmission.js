
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'ponokwai',
  applicationName: 'candidate',
  appUid: 'pqTFmz7TvYkHtpJtBc',
  orgUid: '8c5161bb-17c9-4668-b928-be51a8e9c9db',
  deploymentUid: '92558e85-d4c5-4f45-9299-9a8a3865a668',
  serviceName: 'candidate',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'candidate-dev-candidateSubmission', timeout: 6 };

try {
  const userHandler = require('./api/candidate.js');
  module.exports.handler = serverlessSDK.handler(userHandler.submit, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}